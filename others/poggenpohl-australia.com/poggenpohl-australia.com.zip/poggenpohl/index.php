<html>
<head>
<title>Poggenpohl Australia - Poggenpohl</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<META name=KEYWORDS content="kitchens, german kitchens, design, imported kitchen, poggenpohl, australia, new south wales, northern territory, queensland, act, australian capital territory">
<link href="../style.css" rel="stylesheet" type="text/css">
<script language="JavaScript" type="text/JavaScript">
<!--



<!--

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}
//-->
</script>
<style type="text/css">
a:link {
	text-decoration: none;
	color: #666666;
}

a:visited {
	text-decoration: none;
	color: #666666;
}
a:hover {
	text-decoration: none;
	color: #666666;
}
a:active {
	text-decoration: none;
	color: #666666;
}
</style>
</head>

<body>
<center>
<table width="780" border="0" cellpadding="0" cellspacing="0">
  <!--DWLayoutTable-->
  <tr>
    <td width="780" height="85" valign="top"><div align="left">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td width="14%"><img src="../images/logo.gif" alt="Poggenpohl Australia Logo" width="111" height="110"></td>
          <td width="86%" align="right" class="contentsale">Knowing What Counts </td>
        </tr>
      </table>
    </div></td>
  </tr>
  <tr>
    <td height="18" valign="top" class="footer"><?php include("../top-menu.php");?></td>
  </tr>
  <tr>
    <td height="303" valign="top"><img src="../images/largeimages/image7.jpg" width="780" height="303"></td>
  </tr>
  <tr>
    <td height="35" valign="middle" background="../images/headerBG.gif" class="contentCopy" ><div align="left"><img src="../images/titles/poggenpohlTitle.gif" width="115" height="35" align="middle"></div></td>
  </tr>
  <tr>
    <td height="132" valign="top" class="content"><div align="left"><img src="../images/smallImages/man.jpg" width="250" height="162" align="right" class="imagepadding">
      <p><strong>Poggenpohl - </strong>More than 110 years ago the first German kitchen brand, today the best-known kitchen brand in the world � to be found in over 60 countries all round the world: Poggenpohl. The history of the fitted kitchen is linked with the Poggenpohl name. Throughout the world, Poggenpohl's name is associated with the luxury of individual and exclusive kitchens and with people who know what counts. </p>
      <p>Get to know Poggenpohl in 60 seconds or find out the most important facts about Poggenpohl over the last 110 years. Visit Poggenpohl on 5th Avenue or in Beijing. Locate the Poggenpohl dealer in your locality or read what the media have to say about Poggenpohl. See the symbiosis between traditional manufacturing skills and high-tech production and � open the dialogue with Poggenpohl. </p>
      </div>
      </td>
  </tr>
  <tr>
    <td height="27" valign="middle" class="footer"><?php include("../bottom-menu.php");?></td>
  </tr>
</table>
</center>
</body>
</html>
