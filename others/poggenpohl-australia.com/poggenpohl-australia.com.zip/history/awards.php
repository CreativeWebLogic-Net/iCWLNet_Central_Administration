<html>
<head>
<title>Poggenpohl Australia - Poggenpohl</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<META name=KEYWORDS content="kitchens, german kitchens, design, imported kitchen, poggenpohl, australia, new south wales, northern territory, queensland, act, australian capital territory">
<link href="../style.css" rel="stylesheet" type="text/css">
<script language="JavaScript" type="text/JavaScript">
<!--



<!--

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}
//-->
</script>
<style type="text/css">
a:link {
	text-decoration: none;
	color: #666666;
}

a:visited {
	text-decoration: none;
	color: #666666;
}
a:hover {
	text-decoration: none;
	color: #666666;
}
a:active {
	text-decoration: none;
	color: #666666;
}
</style>
</head>

<body>
<center>
<table width="780" border="0" cellpadding="0" cellspacing="0">
  <!--DWLayoutTable-->
  <tr>
    <td width="780" height="85" valign="top"><div align="left">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td width="14%"><img src="../images/logo.gif" alt="Poggenpohl Australia Logo" width="111" height="110"></td>
          <td width="86%" align="right" class="contentsale">Knowing What Counts </td>
        </tr>
      </table>
    </div></td>
  </tr>
  <tr>
    <td height="18" valign="top" class="footer"><?php include("../top-menu.php");?></td>
  </tr>
  
  <tr>
    <td height="35" valign="middle" background="../images/headerBG.gif" class="contentCopy" ><div align="left">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td width="21%" valign="bottom" bgcolor="#FFFFFF"><span class="pgheading">History &amp; Awards </span> </td>
          <td width="79%">&nbsp;</td>
        </tr>
      </table>
    </div></td>
  </tr>
  <tr>
    <td height="132" valign="top" class="content"><div align="left"><img src="../images/largeimages/awards.jpg" width="288" height="256" align="right" class="imagepadding">        Poggenpohl have been honoured with many international awards for their  innovative ideas, design excellence and quality of product.<br>
          <br>
          Many of Poggenpohl&rsquo;s innovations have become world standards in design.
<p>Often copied but never equalled &ndash; Poggenpohl is the world&rsquo;s number one  brand. </p>
        <ol>
          <li><strong>-&nbsp; Best of  the Best</strong>&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </li>
        </ol>
        <p>IMM International Furniture  Fair,Cologne</p>
        <p><strong>2004 -&nbsp; Good Design Award  - </strong>&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <strong>+  INTEGRATION &reg;</strong><br>
          Chicago Athenaeum </p>
        <p><strong>2001 -&nbsp; Good Design Award</strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <strong>+  SEGMENTO &reg;</strong><br>
          Chicago Athenaeum <strong>&nbsp;</strong></p>
        <p><strong>1992 -&nbsp; </strong>Poggenpohl presents the  world&rsquo;s<strong> first fully recyclable&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; kitchen </strong>and the<strong> &ldquo;ergolift&rdquo;</strong><strong>&nbsp;</strong></p>
        <p><strong>1990 -&nbsp; Premio Italia&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <strong>Form 2400 </strong><br>
          AISES &ndash;  International Academy for Economic and Social Sciences </p>
        <p><strong>1989 &ndash; The fitted kitchen form  2400</strong> &ndash; <br>
          Poggenpohl&rsquo;s  leading model is introduced</p>
        <p><strong>1987 -&nbsp; ION Design Award&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Form 2200 LE </strong><br>
          Holland </p>
        <p><strong>1986 -&nbsp; Stiftung Warnestest Award</strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <strong>Form 2000 CI</strong><br>
          Consumer award,  Berlin </p>
        <p><strong>1986 -&nbsp; Included in INDUSTRIEFORM &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Form 2000 LS</strong><br>
          Essen <strong>&nbsp;</strong></p>
        <p><strong>1986 -&nbsp; Roscoe Design Award&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <strong>Form  2200 diagionale</strong><br>
          USA</p>
        <p><strong>1985 -&nbsp; German Selection&nbsp; </strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <strong>Form 2200 diagionale</strong><br>
          Design Centre Stuttgart</p>
        <p><strong>1984</strong> -&nbsp;  Poggenpohl includes the <strong>form 2200</strong> in its programme</p>
        <p><strong>1983 -&nbsp; German Selection&nbsp; </strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <strong>Dimension 75</strong><br>
          Design Centre  Stuttgart<strong>&nbsp;</strong></p>
        <p><strong>1981 -&nbsp; GS Saftey Award&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <strong>Form 2000 </strong><br>
          German Institute  for Furniture Technology</p>
        <p><strong>1981 -&nbsp; Stiftung Warnestest Award</strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <strong>Form 2000 CF</strong><br>
          Consumer award,  Berlin </p>
        <p><strong>1980 -&nbsp; Design Award &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <strong>Form 2000 CH</strong><br>
          German Design  Congress, Karlsruhe </p>
        <p><strong>1980 -&nbsp; Product Design Award &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Form  2000 HR</strong><br>
          USA </p>
        <p><strong>1979 -&nbsp; GUTE  FORM Prize &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <strong>Form 2000 CH</strong><br>
          Federal German  Prize </p>
        <p><strong>1972 -&nbsp; Cucine &ndash; Moderne -  Arredamenti</strong><br>
          Lombardia Premio  Qualita, Milan</p>
        <p><strong>1970</strong> -&nbsp; Poggenpohl presents the  round kitchen (Kugelkuche) &ldquo;experiment 70&rdquo;, the product of cooperation with the  designer Luigi Colani, designed as a futuristic experimental model looking  forward to the year 2000.</p>
        <p><strong>1968 -&nbsp; GUTE  FORM Prize &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <strong>Form 2000 </strong><br>
          Haus Industrieform <strong>&nbsp;</strong></p>
        <p><strong>1967 -&nbsp;  Trophee International de l&rsquo;Esthetique et de l&rsquo;Elegance </strong><br>
          Comite International de Promotion et de Prestige, Geneva</p>
        <ol>
          <li><strong>-&nbsp; Form 2000</strong> &ndash; the  &ldquo;strip-handled kitchen&rdquo;<strong>&nbsp;</strong></li>
        </ol>
        <ol>
          <li><strong>-&nbsp; </strong>Poggenpohl  presents the serving hatch and the recess as the connection between kitchen and  dining area.<strong>&nbsp;</strong></li>
        </ol>
        <p><strong>1956 -&nbsp; </strong>Poggenpohl is a founding  member of &ldquo;the modern kitchens <br>
          work team&rdquo; (AMK)</p>
        <ol>
          <li><strong>-&nbsp; Gold Medal&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <strong>Poggenpohl Form 1000</strong></li>
        </ol>
        <p>RKW &ndash; Exhibition  in Dusseldorf </p>
        <p><strong>1950 - </strong>With the form  1000 Poggenpohl presents the first German <br>
          unit kitchen in standard production.</p>
        <p><strong>1928 -&nbsp; </strong>Poggenpohl presents the  reform kitchen inspired by <br>
          Werkbund and Bauhaus, this model is  manufactured until 1950</p>
        <p><strong>1923 - </strong>Poggenppohl  presents the &ldquo;ideal kitchen&rdquo;</p>
        <ol>
          <li><strong>-&nbsp; </strong>Poggenpohl builds  kitchens with their own distinct design<strong>&nbsp;</strong></li>
        </ol>
        <p><strong>1900 -&nbsp; </strong>Beginning of standard  production &ndash; kitchens</p>
        <p><strong>1892 -&nbsp; </strong>Friedemir Poggenpohl (1859 -  1924) establishes a <br>
          cabinet-maker&rsquo;s workshop</p>
        <h4>&nbsp;</h4>
        <p>&nbsp;</p>
      </div>      </td>
  </tr>
  <tr>
    <td height="27" valign="middle" class="footer"><?php include("../bottom-menu.php");?></td>
  </tr>
</table>
</center>
</body>
</html>
