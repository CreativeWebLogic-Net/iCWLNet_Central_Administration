<html>
<head>
<title>Poggenpohl Australia - Poggenpohl</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<META name=KEYWORDS content="kitchens, german kitchens, design, imported kitchen, poggenpohl, australia, new south wales, northern territory, queensland, act, australian capital territory">
<link href="../style.css" rel="stylesheet" type="text/css">
<script language="JavaScript" type="text/JavaScript">
<!--



<!--

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}
//-->
</script>
<style type="text/css">
a:link {
	text-decoration: none;
	color: #666666;
}

a:visited {
	text-decoration: none;
	color: #666666;
}
a:hover {
	text-decoration: none;
	color: #666666;
}
a:active {
	text-decoration: none;
	color: #666666;
}
</style>
</head>

<body>
<center>
<table width="780" border="0" cellpadding="0" cellspacing="0">
  <!--DWLayoutTable-->
  <tr>
    <td width="780" height="85" valign="top"><div align="left">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td width="14%"><img src="../images/logo.gif" alt="Poggenpohl Australia Logo" width="111" height="110"></td>
          <td width="86%" align="right" class="contentsale">Knowing What Counts </td>
        </tr>
      </table>
    </div></td>
  </tr>
  <tr>
    <td height="18" valign="top" class="footer"><?php include("../top-menu.php");?></td>
  </tr>
  
  <tr>
    <td height="35" valign="middle" background="../images/headerBG.gif" class="contentCopy" ><div align="left">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td width="16%" valign="bottom" bgcolor="#FFFFFF"><span class="pgheading">Kitchen Care</span> </td>
          <td width="84%">&nbsp;</td>
        </tr>
      </table>
    </div></td>
  </tr>
  <tr>
    <td height="132" valign="top" class="content"><div align="left">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td width="22%"><table width="96%" height="340" border="0" cellpadding="0" cellspacing="0" class="tablegreyborder">
            <tr>
              <td class="content"><strong>Lacquer</strong><br>
                Wood<br>
                Laminate/Melamine<br>
                Stainless Steel<br>
                Aluminium<br>
                Glass<br>
                Ceramic</td>
            </tr>
          </table></td>
          <td width="43%"><table width="99%" height="340" border="0" cellpadding="0" cellspacing="0" class="tablegreyborder">
            <tr>
              <td>
                <p class="content">To preserve the high gloss appearance of these      lacquered surfaces, dust can be wiped off using a soft cloth. There is no      need to apply pressure. For regular cleaning, dip a clean window cloth into      lukewarm water and squeeze out. Using the dampened cloth and applying light      pressure only, gently rub over the surfaces. Finally wipe dry with a soft,      dry cleaning cloth. Never attempt to clean the entire kitchen fronts at one      go, but always concentrate on smaller areas at one time, e.g. one or two      doors. In the case of more heavily soiled surfaces, particularly grease      marks, we recommend adding a little mild household cleaning agent to the      water</p>                
                </td>
            </tr>
          </table></td>
          <td width="35%"><img src="../images/largeimages/laquer.jpg" alt="Laquer" width="340" height="340"></td>
        </tr>
      </table>
     
        </div>      </td>
  </tr>
  <tr>
    <td height="27" valign="middle" class="footer"><?php include("../bottom-menu.php");?></td>
  </tr>
</table>
</center>
</body>
</html>
