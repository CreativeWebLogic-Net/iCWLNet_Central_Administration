<html>
<head>
<title>Poggenpohl Australia - About</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<META name=KEYWORDS content="kitchens, german kitchens, design, imported kitchen, poggenpohl, australia, new south wales, northern territory, queensland, act, australian capital territory">
<link href="../style.css" rel="stylesheet" type="text/css">
<script language="JavaScript" type="text/JavaScript">
<!--



<!--

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}
//-->
</script>
<style type="text/css">
a:link {
	text-decoration: none;
	color: #666666;
}

a:visited {
	text-decoration: none;
	color: #666666;
}
a:hover {
	text-decoration: none;
	color: #666666;
}
a:active {
	text-decoration: none;
	color: #666666;
}
</style>
</head>

<body>
<center>
<table width="780" border="0" cellpadding="0" cellspacing="0">
  <!--DWLayoutTable-->
  <tr>
    <td width="780" height="85" valign="top"><div align="left">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td width="14%"><img src="../images/logo.gif" alt="Poggenpohl Australia Logo" width="111" height="110"></td>
          <td width="86%" align="right" class="contentsale">Knowing What Counts </td>
        </tr>
      </table>
    </div></td>
  </tr>
  <tr>
    <td height="18" valign="top" class="footer"><?php include("../top-menu.php");?></td>
  </tr>
  <tr>
    <td height="303" valign="top"><img src="../images/largeimages/image5.jpg" width="780" height="303"></td>
  </tr>
  <tr>
    <td height="35" valign="middle" background="../images/headerBG.gif" class="contentCopy" ><div align="left"><img src="../images/titles/aboutTitle.gif" width="89" height="35" align="middle"></div></td>
  </tr>
  <tr>
    <td height="132" valign="top" class="content"><div align="left"><img src="../images/smallImages/man.jpg" width="250" height="162" align="right" class="imagepadding">
      <p><strong>Poggenpohl Australia </strong>is a central repository for the projects by licensed dealers of Poggenpohl german designer kitchens. It is also a site for you to find out where these distributors can be found. All our dealers are certified professionals and are carefully chosen to design and implement Poggenpohl imported german designer kitchens. We all work to the high standards exemplified by Poggenpohl and its elegant german design ethics. Our licensed dealers are located throughout most australian capital cities and our design projects are situated in many locations. All our Poggenpohl german designer kitchens are imported with high standards of safety and care so when they are professionally installed you the customer get to enjoy the luxury of Poggenpohl.</p>
      </div>
      </td>
  </tr>
  <tr>
    <td height="27" valign="middle" class="footer"><?php include("../bottom-menu.php");?></td>
  </tr>
</table>
</center>
</body>
</html>
