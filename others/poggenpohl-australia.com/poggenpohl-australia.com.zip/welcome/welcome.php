<html>
<head>
<title>Welcome to Poggenpohl Australia.</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<META name=KEYWORDS content="kitchens, german kitchens, design, imported kitchen, poggenpohl, australia, new south wales, northern territory, queensland, act, australian capital territory">
<link href="../style.css" rel="stylesheet" type="text/css">
<script language="JavaScript" type="text/JavaScript">
<!--
<!--
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
<style type="text/css">
a:link {
	text-decoration: none;
	color: #666666;
}

a:visited {
	text-decoration: none;
	color: #666666;
}
a:hover {
	text-decoration: none;
	color: #666666;
}
a:active {
	text-decoration: none;
	color: #666666;
}
</style>
</head>

<body onLoad="MM_preloadImages('../images/homeDown.gif','../images/linksDown.gif')">
<center>
<table width="780" border="0" cellpadding="0" cellspacing="0">
  <!--DWLayoutTable-->
  <tr>
    <td width="780" height="85" valign="top"><div align="left">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td width="14%"><img src="../images/logo.gif" alt="Poggenpohl Australia Logo" width="111" height="110"></td>
          <td width="86%" align="right" class="contentsale">Knowing What Counts </td>
        </tr>
      </table>
    </div></td>
  </tr>
  <tr>
    <td height="18" valign="top" class="footer"><div align="right"><a href="../index.php">Home</a> | <a href="../aboutUs/index.html">About Us</a> | <a href="../projects/index.html">Projects</a> | <a href="../dealers/index.html">Dealers</a> | <a href="../poggenpohl/index.html">Poggenpohl</a> | <a href="../green-kitchen/index.html">Green Kitchen</a> | <a href="../history/awards.html">History &amp; Awards</a></a> | <a href="../kitchen-care/index.html">Kitchen Care</a> | <a href="../display-sale/index.html">Display Sale</a>  </div></td>
  </tr>
  <tr>
    <td height="303" valign="top"><img src="../images/largeimages/image6.jpg" width="780" height="303"></td>
  </tr>
  <tr>
    <td height="35" valign="middle" background="../images/headerBG.gif" class="contentCopy" ><div align="left"><img src="../images/titles/welcomeTitle.gif" width="88" height="35" align="middle"></div></td>
  </tr>
  <tr>
    <td height="132" valign="top" class="content"><div align="left"><img src="../images/smallImages/smallImageMain.jpg" width="250" height="162" align="right" class="imagepadding">Derived from cubism by Le Corbusier, purism is the art movement oriented towards the severe form and clear structure of composition which also found its expression in the Bauhaus school of design. Modern purism from Poggenpohl is based on this tradition, applying it to the design and functionality of the modern kitchen.
      </div>
      <p align="left">Experience modern purism from Poggenpohl in our ranges PLUSMODO - Design Jorge Pensi, +INTEGRATION and +SEGMENTO as timeless interpretations of purity and simplicity.</p>
      </td>
  </tr>
  <tr>
    <td height="27" valign="middle" class="footer"><div align="right"><a href="welcome.html">Home</a> | <a href="../aboutUs/index.html">About Us</a> | <a href="../projects/index.html">Projects</a> | <a href="../dealers/index.html">Dealers</a> | <a href="../poggenpohl/index.html">Poggenpohl</a>   | <a href="../sitemap.html">Site Map</a></div></td>
  </tr>
</table>
</center>
</body>
</html>
