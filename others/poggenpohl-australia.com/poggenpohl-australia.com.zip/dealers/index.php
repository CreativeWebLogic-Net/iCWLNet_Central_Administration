<html>
<head>
<title>Poggenpohl Australia - Dealers</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<META name=KEYWORDS content="kitchens, german kitchens, design, imported kitchen, poggenpohl, australia, new south wales, northern territory, queensland, act, australian capital territory">
<link href="../style.css" rel="stylesheet" type="text/css">
<script language="JavaScript" type="text/JavaScript">
<!--



<!--

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}
//-->
</script>
<style type="text/css">
a:link {
	text-decoration: none;
	color: #666666;
}

a:visited {
	text-decoration: none;
	color: #666666;
}
a:hover {
	text-decoration: none;
	color: #666666;
}
a:active {
	text-decoration: none;
	color: #666666;
}
</style>
</head>

<body>
<center>
<table width="780" border="0" cellpadding="0" cellspacing="0">

  <tr>
    <td width="780" height="85" valign="top"><div align="left">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td width="14%"><img src="../images/logo.gif" alt="Poggenpohl Australia Logo" width="111" height="110"></td>
          <td width="86%" align="right" class="contentsale">Knowing What Counts </td>
        </tr>
      </table>
    </div></td>
  </tr>
  <tr>
    <td height="18" valign="top" class="footer"><?php include("../top-menu.php");?></td>
  </tr>
  <tr>
    <td height="303" valign="top"><img src="../images/largeimages/image8.jpg" width="780" height="303"></td>
  </tr>
  <tr>
    <td height="35" valign="middle" background="../images/headerBG.gif" class="contentCopy" ><div align="left"><img src="../images/titles/dealersTitle.gif" width="80" height="35" align="middle"></div></td>
  </tr>
  <tr>
    <td height="22" valign="middle" class="content">&nbsp;</td>
  </tr>
  <tr>
    <td height="132" valign="top" class="content"><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td width="55%"><table width="96%" height="340" border="0" align="center" cellpadding="0" cellspacing="0" class="tablegreyborder">
          <tr>
            <td class="content"><table width="90%" border="0" align="center" cellpadding="0" cellspacing="0">
                <tr>
                  <td class="content">NSW</td>
                  <td class="content"> a la Carte Design</td>
                </tr>
                <tr>
                  <td class="content">ACT</td>
                  <td class="content">Hugh Gordon</td>
                </tr>
                <tr>
                  <td class="content">QLD</td>
                  <td class="content">Da Vinci Design</td>
                </tr>
                <tr>
                  <td class="content">VIC</td>
                  <td class="content">Pepper Kitchens &amp; Interiors</td>
                </tr>
                <tr>
                  <td class="content">TAS</td>
                  <td class="content">a la Carte Design</td>
                </tr>
                <tr>
                  <td class="content">SA </td>
                  <td class="content">a la Carte Design</td>
                </tr>
                <tr>
                  <td class="content">WA</td>
                  <td class="content"> a la Carte Design </td>
                </tr>
                <tr>
                  <td class="content">NT</td>
                  <td class="content"> a la Carte Design</td>
                </tr>
                <tr>
                  <td class="content">NZ&nbsp;</td>
                  <td class="content">Azente</td>
                </tr>
                <tr>
                  <td colspan="2" align="center" class="content">International Interiors</td>
                  </tr>
              </table></td>
          </tr>
        </table></td>
        <td width="45%"><img src="../images/largeimages/dealers.jpg" alt="Poggenpohl Australian Dealers" width="340" height="340"></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="27" valign="middle" class="footer"><?php include("../bottom-menu.php");?></td>
  </tr>
</table>
</center>
</body>
</html>
