<html>
<head>
<title>Poggenpohl Australia - NSW Dealers</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<META name=KEYWORDS content="kitchens, german kitchens, design, imported kitchen, poggenpohl, australia, new south wales, northern territory, queensland, act, australian capital territory">
<link href="../style.css" rel="stylesheet" type="text/css">
<script language="JavaScript" type="text/JavaScript">
<!--
<!--
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
<style type="text/css">
a:link {
	text-decoration: none;
	color: #666666;
}

a:visited {
	text-decoration: none;
	color: #666666;
}
a:hover {
	text-decoration: none;
	color: #666666;
}
a:active {
	text-decoration: none;
	color: #666666;
}
</style>
</head>

<body onLoad="MM_preloadImages('../images/homeDown.gif','../images/AboutDown.gif','../images/ProjectsDown.gif','../images/DealersDown.gif','../images/PoggenpohlDown.gif','../images/linksDown.gif')">
<center>
<table width="780" border="0" cellpadding="0" cellspacing="0">
  <!--DWLayoutTable-->
  <tr>
    <td width="780" height="85" valign="top"><div align="left"><img src="../images/logo.gif" width="111" height="110"></div></td>
  </tr>
  <tr>
    <td height="18" valign="top"><div align="right"><a href="../index.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('home','','../images/homeDown.gif',1)"><img src="../images/homeUp.gif" name="home" width="53" height="19" border="0"></a><a href="../aboutUs/index.html" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('about','','../images/AboutDown.gif',1)"><img src="../images/AboutUp.gif" name="about" width="82" height="19" border="0"></a><a href="../projects/index.html" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('projects','','../images/ProjectsDown.gif',1)"><img src="../images/ProjectsUp.gif" name="projects" width="74" height="19" border="0"></a><a href="index.html" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('dealers','','../images/DealersDown.gif',1)"><img src="../images/DealersUp.gif" name="dealers" width="72" height="19" border="0"></a><a href="../poggenpohl/index.html" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('poggenpohl','','../images/PoggenpohlDown.gif',1)"><img src="../images/PoggenpohlUp.gif" name="poggenpohl" width="98" height="20" border="0"></a><a href="../links/index.html" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('links','','../images/linksDown.gif',1)"><img src="../images/linksUp.gif" name="links" width="58" height="21" border="0"></a></div></td>
  </tr>
  <tr>
    <td height="303" valign="top"><img src="../images/largeimages/image8.jpg" width="780" height="303"></td>
  </tr>
  <tr>
    <td height="35" valign="middle" background="../images/headerBG.gif" class="contentCopy" ><div align="left"><img src="../images/titles/titleNSW.gif" width="157" height="35" align="middle"></div></td>
  </tr>
  <tr>
    <td height="132" valign="top" class="content"><div align="left">
      <p align="left"><strong>Showrooms &amp; dealers </strong></p>
      <table align="left" cellpadding="0" cellspacing="0">
        <tr>
          <td width="200" height="137" align="left" valign="top"><table cellpadding="0" cellspacing="0">
              <tr>
                <td align="left" valign="top" width="175"><p class="Text"><strong>A la Carte Design</strong><br> 
                  45 Burton Street <br>
                      EAST SYDNEY 2010 <br>
                      AUSTRALIA <br>
                      Fon: 02 9332 1160 <br>
                      Fax: 02 9332 1445 </p>
                  <p><a href="mailto:info@alacartedesign.com.au">eMail </a><a href="http://WWW.ALACARTEDESIGN.COM.AU">Internet </a></p></td>
              </tr>
          </table></td>
          <td align="left" valign="top" width="200"><table cellpadding="0" cellspacing="0">
              <tr>
                <td align="left" valign="top" width="175"><p><span class="Text"><strong>Da Vinci Design PTY Ltd. </strong><br>
                  Level 1 Brisbane Design Centre <br>
              46 Douglas Street <br>
              MILTON, QUEENSLAND 4064 <br>
              AUSTRALIA <br>
              Fon: +61-7-33678955 <br>
              Fax: +61-7 -33673499<br>
                </span><a href="mailto:davinci1@bigpond.net.au">eMail </a></p>                  </td>
              </tr>
          </table></td>
        </tr>
        <tr></tr>
        <tr>
          <td align="left" valign="top" width="200"><table cellpadding="0" cellspacing="0">
              <tr>
                <td align="left" valign="top" width="175"><span class="Text"><strong>Pepper Kitchens &amp; Interiors </strong><br>
            213 Bay St. <br>
            BRIGHTON (MELBOURNE) 3186 <br>
            AUSTRALIA <br>
            Fon: +61-3-9530 6680 <br>
            Fax: +61-3-9530 6088<br> 
            </span><a href="mailto:info@pepperkitchens.com.au">eMail </a></td>
              </tr>
          </table></td>
          <td align="left" valign="top" width="175"></td>
        </tr>
      </table>
      <div align="center"></div>
      <p>&nbsp;</p>
      <blockquote>
        <p>&nbsp; </p>
      </blockquote>
    </div>
      </td>
  </tr>
  <tr>
    <td height="27" valign="middle" class="footer"><?php include("../bottom-menu.php");?></td>
  </tr>
</table>
</center>
</body>
</html>
