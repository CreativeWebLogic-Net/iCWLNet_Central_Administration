<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title><?=$PageDetails['pagetitle'];?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<?=$PageDetails['metadata'];?>
<script src="/main/ajax.js"></script>
<script>

	MaxCOs['/<?=TEMPLATESDIR.$Page[$CurrentPage]['template']."/"?>']=<?=$MaxCOs[$Page[$CurrentPage]['template']]?>;
</script>
<style type="text/css">
<!--
body {
	
	margin-top: 20px;
}
-->
</style>
<link href="style.css" rel="stylesheet" type="text/css">
<style type="text/css">
<!--
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: none;
}
a:active {
	text-decoration: none;
}
.style2 {
	font-family: Arial, Helvetica, sans-serif;
	color: #E26FE6;
}
-->
</style>
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}
//-->
</script>
</head>

<body  background="images/mainBG.gif" >
<center>
  <table width="700" border="0">
    <tr>
      <td align="right"><?=createinstance(12);?></td>
    </tr>
  </table>
  <table width="700" border="0" cellpadding="0" cellspacing="0">
  <!--DWLayoutTable-->
  <tr>
    <td width="448" rowspan="2" valign="top"><?=createinstance(10);?></td>
    <td width="252" height="114" valign="top" bgcolor="#FFFFFF"><?=createinstance(13);?></td>
  </tr>
  <tr>
    <td height="192" valign="top" bgcolor="#FFFFFF"><table width="100%" border="0" cellpadding="0" cellspacing="0">
      <!--DWLayoutTable-->
      <tr>
        <td width="252" height="192" valign="top" bgcolor="#FFFFFF"><?=createinstance(11);?></td>
      </tr>
    </table></td>
  </tr>
  
  
  <tr>
    <td colspan="2" align="center" valign="top" bgcolor="#FFFFFF"><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td><?=createinstance(8);?></td>
        <td><?=createinstance(9);?></td>
      </tr>
    </table></td>
  </tr>
  <tr bgcolor="#FFFFFF">
    <td height="180" colspan="2" align="left" valign="top" class="content"><h1 align="center"><span class="headingText">
      <?=createinstance(7);?>
      <br>
    </span></h1>
    <table width="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td><?=$PageDetails['pagetitle'];?></td>
          </tr>
      </table>
      <p align="left">
        <?=createinstance(1);?>
        <br />
        <br />
        <?=createinstance(2);?>
        <br />
        <br />
        <?=createinstance(3);?>
        <br />
        <br />
        <?=createinstance(4);?>
</p>
      <p align="center">&nbsp;</p>
      </td>
    </tr>
  <tr>
    <td height="20" colspan="2" valign="top"><img src="images/footerPt1.gif" width="700" height="20"></td>
    </tr>
  <tr background="images/footerPt2.gif" valign="middle" >
    <td height="39" colspan="2" class="footer"><div align="right">
      <?=createinstance(5);?>&nbsp;&nbsp;&nbsp;
    </div></td>
    </tr>
  <tr>
    <td height="10" colspan="2" valign="top"><img src="images/footerPt3.gif" width="700" height="10"></td>
    </tr>
  <tr>
    <td height="19" colspan="2" valign="top" class="DesignedBy"><div align="center" class="">
      <?=createinstance(6);?>
    </div></td>
    </tr>
</table>
</center>
</body>
</html>
