<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?=$PageDetails['metadata'];?>
<title>Expo Rewards Vehicle Carbon Reduction System - <?=$PageDetails['pagetitle'];?></title>
<script src="/main/ajax.js"></script>
<script>

	MaxCOs['/<?=TEMPLATESDIR.$Page[$CurrentPage]['template']."/"?>']=<?=$MaxCOs[$Page[$CurrentPage]['template']]?>;
</script>
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}

.title{color:#2863de;
font-family:Arial, Helvetica, sans-serif;
font-size:14px;
font-weight:bold;
}
-->
</style>
<script src="../Scripts/AC_RunActiveContent.js" type="text/javascript"></script>
</head>

<body>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
    <tr>
      <td height="19" colspan="2" align="right"><p><span >
        <?=createinstance(8);?>
      </span></p>      </td>
    </tr>
  <tr>
    <td width="15%" rowspan="3" bgcolor="e0eefc"><p>&nbsp;</p>
      <p><img src="images/horizontal_solution_PP.gif" width="155" height="66" /></p>
      <p>&nbsp;</p>
      <p><span >
        <?=createinstance(4);?>
      </span></p>
    <p><span >
      <?=createinstance(5);?>
    </span></p>
    <p><span >
      <?=createinstance(6);?>
    </span></p></td>
    <td width="85%" height="0"><script type="text/javascript">
AC_FL_RunContent( 'codebase','http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,28,0','width','480','height','90','src','images/ExpoheaderMedium','quality','high','pluginspage','http://www.adobe.com/shockwave/download/download.cgi?P1_Prod_Version=ShockwaveFlash','movie','images/ExpoheaderMedium' ); //end AC code
</script><noscript><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,28,0" width="480" height="90">
      <param name="movie" value="images/ExpoheaderMedium.swf" />
      <param name="quality" value="high" />
      <embed src="images/ExpoheaderMedium.swf" quality="high" pluginspage="http://www.adobe.com/shockwave/download/download.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash" width="480" height="90"></embed>
    </object></noscript>
  <img src="images/wCars002_20-_20car_20cartoo.jpg" width="182" height="90" /></td>
  </tr>
  <tr>
    <td background="images/BUTTONS-BAR-PIECE.jpg"><span >
      <?=createinstance(7);?>
    </span></td>
  </tr>
  <tr>
    <td><p class="title"><?=$PageDetails['pagetitle'];?>
    </p>
      <p ><?=createinstance(1);?> </p>
      <p >
        <?=createinstance(2);?>
      </p>
      <p >
        <?=createinstance(3);?>
          </p></td>
  </tr>
  <tr>
    <td colspan="2" align="right"><span >
      <iframe src="/main/ajax-iframe.php" name="AJAXIFrame" id="AJAXIFrame" width="0" marginwidth="0" height="0" marginheight="0" scrolling="No" frameborder="0"></iframe>
      <?=createinstance(9);?>
    </span></td>
  </tr>
</table>
</body>
</html>
