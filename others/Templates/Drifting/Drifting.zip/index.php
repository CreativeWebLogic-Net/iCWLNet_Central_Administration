<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en-AU">
<head>
  <meta http-equiv="content-type" content="application/xhtml+xml; charset=UTF-8" />
  <title><?=$PageDetails['pagetitle'];?></title>
	<?=$PageDetails['metadata'];?>

  <link rel="stylesheet" type="text/css" href="css/drifting_screen.css" media="screen, tv, projection" />
  <link rel="stylesheet" type="text/css" href="css/drifting_print.css" media="print" />
  <script src="/main/ajax.js"></script>
	<script>

	MaxCOs['/<?=TEMPLATESDIR.$Page[$CurrentPage]['template']."/"?>']=<?=$MaxCOs[$Page[$CurrentPage]['template']]?>;
</script>
</head>

<body>
<div align="right">
  <?=createinstance(8);?>
  
  <!-- Layout container starts -->
</div>
<div id="layoutBox">

  <!-- HEADER: controls the header layout, images, title and subTitle. -->
  <div id="headerBox">
    <div id="headerLeftBox">
      <?=createinstance(9);?>
      <br />
    </div>
    <div id="headerRightBox">
      &nbsp;
    </div>
  </div>

  <!-- MENU: include as many submenus as you want.  Menu groups should begin with a
       <h1> and then all menu links need to be defined in a <div class="menuGroup">.
       The <span class="noDisplay"> | </span> after each link only needs to be included
       if this site will be loaded in a text only browser -->
  <div id="menuBox">
    <h1>&nbsp;</h1>
    <div class="menuGroup">
      <p>
        <?=createinstance(6);?>
      </p>
      <p>
        <?=createinstance(7);?>      
        </p>
      <h1>&nbsp;</h1>
      <div class="menuGroup">
        <p>
          <?=createinstance(10);?>
        </p>
      </div>
    </div>

  </div>

  <!-- MAIN CONTENT : to add new headings, include a <h1> and then as many <p> blocks
       as you'd like.  <h2> will create subheadings. To finish a section, include a
       <br/> to clearly define it. -->
  <div id="mainContent">

    <h1>
      <?=$PageDetails['pagetitle'];?>
    </h1>
    <p>
      <?=createinstance(1);?>
      <br />
      <br />
      <?=createinstance(2);?>
      <br />
      <br />
      <?=createinstance(3);?>
      <br />
      <br />
      <?=createinstance(4);?>
    </p>

    <br />

    <!-- FOOTER: whatever you want in here - maybe a last updated or breadcrumb? -->
    <div class="footer">
      <?=createinstance(5);?>
    </div>
  </div>

  <!-- BUG FIX: This corrects another IE rendering bug....  You notice it only when the menu container length is
       greater than the main content container.  Without this, when an a:hover is triggered in the main container,
       IE reflows the page and cuts off the menu at the bottom of the main container. -->
  <div class="spacer">
  </div>

</div>
<!-- Layout container ends -->

</body>
</html>