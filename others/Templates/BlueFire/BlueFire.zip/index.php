<HTML><HEAD>
<META http-equiv=Content-Type content="text/html; charset=windows-1252">
<title><?=$PageDetails['pagetitle'];?></title>
<?=$PageDetails['metadata'];?>

<STYLE type=text/css>A {
	TEXT-DECORATION: none
}
A:hover {
	COLOR: #663399
}
</STYLE>
<script src="<?=$PageDetails['templatedir'];?>jscript/functions.js"></script>
<script src="/main/ajax.js"></script>
<script>

	MaxCOs['/<?=TEMPLATESDIR.$Page[$CurrentPage]['template']."/"?>']=<?=$MaxCOs[$Page[$CurrentPage]['template']]?>;
</script>
</HEAD>

<BODY vLink=#666699 aLink=#663399 link=#666699 bgColor=#CCCCDD  onLoad="OnPageLoadStartup()">

<CENTER>
<TABLE cellSpacing=0 cellPadding=0 width=460 align=center border=0>
  <TBODY>
  <TR>
    <TD width="565">
      <TABLE cellSpacing=0 cellPadding=0 width="100%" border=0>
        <TBODY>
        <TR>
          <TD align="right"><?=createinstance(7);?></TD>
        </TR>
        <TR>
          <TD width="558"><IMG src="img/top.gif" border=0 width="558" height="20"></TD></TR>
        <TR>
          <TD width=558 height="70" align="center" bgcolor="#666699"><?=createinstance(6);?>          </TD>
        </TR>
        </TBODY></TABLE></TD></TR>
  <TR vAlign=top>
    <TD>
      <TABLE cellSpacing=0 cellPadding=0 width="454" border=0>
        <TBODY>
        <TR>
          <TD><IMG height=1 src="img/px.gif" width=12></TD>
          <TD vAlign=top>
            <div align="center">
              <center>
            <TABLE cellSpacing=0 cellPadding=10 width=533 bgColor=#ffffff 
            border=0>
              <TBODY>
              <TR>
                <TD width="508">
                  <div align="center">
                    <center>
                      <?=createinstance(5);?>
                    </center>
                  </div>                </TD></TR>
              <TR>
                <TD width="510" valign="top">
                <center>
<!-- Begin AdDynamix Code -->
<?=$PageDetails['pagetitle'];?>
<HR width="100%" color=#330066 noShade SIZE=1>
<br>
<?=createinstance(1);?>
<br>
<br>
<?=createinstance(2);?>
<br>
<br>
<?=createinstance(3);?>
<br>
<br>
<?=createinstance(4);?></TD>
              </TR></TBODY></TABLE></center>
            </div>          </TD>
          <TD><IMG height=1 src="img/px.gif" 
        width=12></TD></TR>
        <TR>
          <TD colspan="3">
            <p align="center"><img border="0" src="img/bottom.gif" width="558" height="25"></p>          </TD>
        </TR>
        <TR>
          <TD width=558 colspan="3" bgcolor="#666699" height="35">&nbsp;</TD>
        </TR>
        <TR>
          <TD height="35" colspan="3" align="center" bgcolor="#666699"><?=createinstance(8);?></TD>
        </TR>
        </TBODY></TABLE></TD></TR></TBODY></TABLE>
</CENTER> </P>
</BODY></HTML>
