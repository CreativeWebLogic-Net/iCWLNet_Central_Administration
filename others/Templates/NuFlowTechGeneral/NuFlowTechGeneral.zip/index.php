<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>NuFlowTech Australia - <?=$PageDetails['pagetitle'];?></title>
<? include(HEADERCODE); ?>
<meta name="keywords" content="cured in place pipe, pipe lining, trechless sewer repair, leak repair, queensland plumbing, qld, plumbing, plumber, pipe, repipe, re pipe, reline, renew, repair, cctv, camera, sewerage, mainline, cracked, broken, blockage, chokes, water, potable, sewer, stormwater, copper, pvp, hdpe, poly, downpipe, junction, trap, bend, nuflow, nuflow tech australia,">
<meta name="description" content="Nu Flow Tech, Specialises in trenchless technolgy, Plumbling, Reline, Repipe, Renew.">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
a:link {
	color: #2560AC;
}
a:visited {
	color: #2560AC;
}
a:hover {
	color: #2560AC;
}
a:active {
	color: #2560AC;
}
-->
</style>

<link REL="SHORTCUT ICON" HREF="favicon.ico">
<link href="nuflow.css" rel="stylesheet" type="text/css">
</head>
<body class="headerbg" onload="eval(LoadFunctions);">
<table width="815" border="0" align="center" cellpadding="4" cellspacing="0">
  <tr>
    <td width="815" align="right"><span class="content">
      <?=createinstance(5);?>
    </span></td>
  </tr>
  <tr>
    <td><img src="images/header.jpg" alt="Reline renew repair" width="815" height="170"></td>
  </tr>
  <tr>
    <td><span class="content">
      <?=createinstance(4);?>
    </span></td>
  </tr>
  <tr>
    <td><h2><span class="content">
      <?=$PageDetails['pagetitle'];?>
    </span></h2>
      <h2><span class="content">
        <?=createinstance(1);?>
      </span></h2>
      <p><span class="content">
        <?=createinstance(2);?>
      </span></p>
      <p><span class="content">
        <?=createinstance(3);?>
      </span></p>
    <p>
      <iframe src="/main/ajax-iframe.php" name="AJAXIFrame" id="AJAXIFrame" width="0" marginwidth="0" height="0" marginheight="0" scrolling="No" frameborder="0"></iframe>
    </p></td>
  </tr>
  <tr>
    <td><table width="100%"  border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td background="images/bottom2.jpg"><div align="center">
              <table width="805" height="69"  border="0" cellpadding="0" cellspacing="0">
                <tr>
                  <td valign="bottom" background="images/1800nuflow.jpg"><div align="right" class="smltxt">
                      <div align="center">&copy; Copyright 2008 Nu Flow Australia. All rights reserved. | <a href="http://www.digitalblitz.com.au">Website Services By Digital Blitz</a> <br>
                      </div>
                  </div></td>
                </tr>
            </table></td>
        </tr>
      </table>
      <script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
      </script>
      <script type="text/javascript">
var pageTracker = _gat._getTracker("UA-5139250-1");
pageTracker._initData();
pageTracker._trackPageview();
      </script></td>
  </tr>
</table>
</body>
</html>