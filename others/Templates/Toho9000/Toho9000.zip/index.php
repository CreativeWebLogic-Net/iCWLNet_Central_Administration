<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title><?=$PageDetails['pagetitle'];?></title>
	<?=$PageDetails['metadata'];?>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="style.css" rel="stylesheet" type="text/css">
<style type="text/css">
<!--
body {
	background-image: url(<?=TEMPLATESDIR.$Page[$CurrentPage]['template']."/"?>Pics/bg.gif);
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
a:link {
	color: #5273A5;
	text-decoration: none;
}
a:visited {
	text-decoration: none;
	color: #5273A5;
}
a:hover {
	text-decoration: none;
	color: #000000;
}
a:active {
	text-decoration: none;
	color: #5273A5;
}
.style2 {
	font-size: 24px;
	font-weight: bold;
}
.style4 {color: #000000}
.style5 {	font-size: 24px;
	font-weight: bold;
	color: #000000;
}
.tableborder {	border: 1px solid #666666;
}
.style6 {color: #FFFFFF}
-->
</style>
</head>

<body>
<center>
<table width="749" border="0" cellpadding="0" cellspacing="0" class="main_border">
  <!--DWLayoutTable-->
  <tr>
    <td height="18" colspan="2" valign="top"><img src="Pics/toho9000layout2_02.gif" width="662" height="18" align="right"></td>
    <td width="86" background="Pics/link_background_top.gif" class="top-links"><?=createinstance(8);?></td>
    </tr>
  <tr>
    <td height="139" colspan="2" valign="top"><img src="Pics/toho9000layout2_05.gif" width="662" height="139" align="right"></td>
    <td valign="top"><img src="Pics/toho9000layout2_06.gif" width="86" height="139"></td>
    </tr>
  <tr>
    <td width="494" height="22" valign="middle" background="Pics/menu_bg.gif" class="main_menu"><div align="left">
      <?=createinstance(6);?>
    </div></td>
    <td colspan="2" valign="top" class="menu_right_bottom"><img src="Pics/toho9000layout2_08.gif" width="254" height="22"></td>
    </tr>
	<tr>
		<TD height="16" colspan="3" valign="middle" background="Pics/menu_bg.gif" class="main_menu"><div align="left">
		  <?=createinstance(7);?>
	  </div></TD>
	</tr>
  <tr>
    <td height="274" colspan="3" valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0">
          <!--DWLayoutTable-->
          <tr>
            <td width="748" height="171" valign="top" bgcolor="#FFFFFF" class="content"><p align="left" class="style2">
              <?=$PageDetails['pagetitle'];?>
              <br>
              <img src="Pics/dotted_Line.gif" width="725" height="1" align="top"></p>
              <p>
                <?=createinstance(1);?>
                <br />
                <br />
                <?=createinstance(2);?>
                <br />
                <br />
                <?=createinstance(3);?>
                <br />
                <br />
                <?=createinstance(4);?>
              </p>
            </td>
          </tr>
          <tr>
            <td height="70" valign="top"><img src="Pics/toho9000layout2_10.gif" width="748" height="70"></td>
          </tr>
          <tr>
            <td height="33" background="Pics/bottom_bg.gif" class="top-links"><div align="center" class="main_menu">
              <?=createinstance(5);?>
            </div></td>
          </tr>
            </table></td>
    </tr>
  <tr>
    <td height="1"></td>
    <td width="168"></td>
    <td></td>
  </tr>
</table>
</center>
</body>
</html>
