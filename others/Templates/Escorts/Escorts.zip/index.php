<?
	include("admin/DB_Class.php");
	$r=new ReturnRecord();
	$r->AddTable("Content");
	$r->AddSearchVar(13);
	$Insert=$r->GetRecord();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?=$PageDetails['pagetitle'];?></title>
<? include(HEADERCODE); ?>
<link href="style.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-top: 20px;
	background-image: url(images/bgtile.gif);
	background-repeat: repeat-x;
}
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: none;
}
a:active {
	text-decoration: none;
}
.style1 {font-size: 9}
.style2 {font-size: 9px}
-->
</style></head>

<body onload="eval(LoadFunctions);">
<center>
<table width="673" border="0" cellpadding="0" cellspacing="0">
  <!--DWLayoutTable-->
  <tr>
    <td height="19" colspan="2" align="right" valign="top"><span class="whitelink">
      <?=createinstance(5);?>
    </span></td>
    </tr>
  <tr>
    <td width="220" height="118" valign="middle"><a href="images/pentagon.grand_03.gif"></a><span class="whitelink">
      <?=createinstance(6);?>
    </span></td>
    <td width="453"><span class="whitelink">
      <?=createinstance(7);?>
    </span></td>
  </tr>
  <tr>
    <td height="31" colspan="2" align="center" valign="middle" background="images/pentagon.grand_06.gif" class="menu"><span class="whitelink">
      <?=createinstance(4);?>
    </span></td>
  </tr>
  
  <tr>
    <td height="157" colspan="2" valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0">
      <!--DWLayoutTable-->
      <tr>
        <td width="673" height="149" align="left" valign="top" background="images/midBG.gif" class="content"><h2><?=$PageDetails['pagetitle'];?>
            
        </h2>
        <?=createinstance(1);?>
          <p><span class="whitelink">
            <?=createinstance(2);?>
          </span></p>
          <p><span class="whitelink">
            <?=createinstance(3);?>
          </span></p>
          <div align="left"></div>
          <iframe src="/main/ajax-iframe.php" name="AJAXIFrame" id="AJAXIFrame" width="0" marginwidth="0" height="0" marginheight="0" scrolling="No" frameborder="0"></iframe></td></tr>
    </table></td>
  </tr>
  <tr>
    <td height="2"></td>
    <td></td>
  </tr>
  <tr>
    <td height="30" colspan="2" valign="middle" bgcolor="#000000" class="footer"><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td width="60%" align="left"><a href="http://www.iwebbiz.com.au" target="_blank">Website Design Development Promotion By IWebBiz </a></td>
        <td width="40%" align="right"><a href="http://www.bubblecms.net">Powered By Bubble CMS</a></td>
        </tr>
    </table></td>
  </tr>
</table>
</center>
</body>
</html>
