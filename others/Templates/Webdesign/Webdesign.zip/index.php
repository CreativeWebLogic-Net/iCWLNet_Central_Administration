<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<title><?=$PageDetails['pagetitle'];?></title>
<? include(HEADERCODE); ?>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<link href="style.css" rel="stylesheet" type="text/css" />
</head>

<body onload="eval(LoadFunctions);">
<table width="85%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td><div id="wrapper">
      <div id="wrapper-i">
        <div id="header">
          <img src="images/header2.jpg" width="765" height="131" /><?=createinstance(7);?>
          <!-- end b-nav -->
        </div>
        <!-- end header -->
        <div id="spacer"> </div>
        <!-- end spacer -->
        <div id="body">
          <div id="body-i">
          <div id="left">
            <iframe src="/main/ajax-iframe.php" name="AJAXIFrame" id="AJAXIFrame" width="0" marginwidth="0" height="0" marginheight="0" scrolling="No" frameborder="0"></iframe>
            <p><span class="content">
              <?=createinstance(4);?>
              </span>
                <!-- end left -->
            </p>
            <p><span class="content">
              <?=createinstance(5);?>
            </span></p>
            <p><span class="content">
              <?=createinstance(6);?>
            </span></p>
            </div>
            <div id="right">
              <h2>
                <!-- end right -->
                <span class="content">
                <?=$PageDetails['pagetitle'];?>
                </span></h2>
              <h2><span class="content">
                <?=createinstance(1);?>
              </span></h2>
              <p><span class="content">
                <?=createinstance(2);?>
              </span></p>
              <p><span class="content">
                <?=createinstance(3);?>
              </span></p>
            </div>
            <div id="footer-p"> </div>
            <!-- end footer-p -->
            <div id="footer">
              <div class="l">
                <div class="r">
                  <div id="foot-nav">
                    <div class="l">
                      <div class="r"><span class="content">
                        <?=createinstance(7);?>
                      </span></div>
                    </div>
                  </div>
                  <!-- end foot-nav -->
                  <p>&nbsp;</p>
                </div>
              </div>
            </div>
            <!-- end footer -->
          </div>
          <!-- end body-i -->
        </div>
        <!-- end body -->
      </div>
      <!-- end wrapper-i -->
    </div></td>
  </tr>
</table>
<!-- end wrapper -->
</body>
</html>
