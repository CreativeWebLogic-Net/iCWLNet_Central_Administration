<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?=$PageDetails['pagetitle'];?></title>
<link href="<?=$PageDetails['templatedir'];?>css/1.css" rel="stylesheet" type="text/css" />
<? include(HEADERCODE); ?>
</head>

<body onload="eval(LoadFunctions);">
<a name="top" id="top"></a>
<?=createinstance(9);?>
<center>
		<div id="menu">
		  <?=createinstance(8);?>
		</div>
		
		<div id="header">
				<h1>
				  <?=$PageDetails['pagetitle'];?>
				</h1>
				<h2>&nbsp;</h2>
  </div>
		
		<div id="content">
		  <p class="introduction">
				  <?=createinstance(1);?>
				</p>
				
				<div id="sidebar">
						<h1>&nbsp;</h1>
				  
				    <?=createinstance(4);?>
				  
				  <p>
				    <?=createinstance(5);?>
				  </p>
				  <p>
				    <?=createinstance(6);?>
				  </p>
				</div>
				
		  <div id="mainbar">
				  <h1>
<?=createinstance(2);?>
						</h1>
						
						<h1><?=createinstance(3);?>
						</h1>
						<p>
						  <iframe src="/main/ajax-iframe.php" name="AJAXIFrame" id="AJAXIFrame" width="0" marginwidth="0" height="0" marginheight="0" scrolling="No" frameborder="0"></iframe>
						</p>
			    </div>
		
  </div>
  <div id="footer">
    <?=createinstance(7);?>
    <br />
    <a href="http://www.iwebbiz.com.au" target="_blank">Website Design Development Promotion IWebBiz   </a></div>
</center>
</body>
</html>
