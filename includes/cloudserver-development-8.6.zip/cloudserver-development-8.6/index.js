'use strict'; // eslint-disable-line strict

require('./lib/server.js')();
