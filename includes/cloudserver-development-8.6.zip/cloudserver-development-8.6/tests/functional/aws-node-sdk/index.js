'use strict'; // eslint-disable-line strict
require('./test.js'); // eslint-disable-line import/no-unresolved
