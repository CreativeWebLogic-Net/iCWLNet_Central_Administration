const async = require('async');
const assert = require('assert');

const { s3middleware } = require('arsenal');
const withV4 = require('../../support/withV4');
const BucketUtility = require('../../../lib/utility/bucket-util');
const {
    describeSkipIfNotMultipleOrCeph,
    fileLocation,
    awsS3,
    awsLocation,
    awsBucket,
    azureLocation,
    azureLocationMismatch,
    getAzureClient,
    getAzureContainerName,
    genUniqID,
} = require('../utils');

const azureMpuUtils = s3middleware.azureHelper.mpuUtils;

const azureContainerName = getAzureContainerName(azureLocation);
const azureClient = getAzureClient();
const azureTimeout = 20000;

const maxSubPartSize = azureMpuUtils.maxSubPartSize;
const smallBody = Buffer.from('I am a body', 'utf8');
const bigBody = Buffer.alloc(maxSubPartSize + 10);
const s3MD5 = 'bd43a393937412d119abcdbbc9bd363a-2';
const expectedContentLength = '104857621';

let s3;
let bucketUtil;

function getCheck(key, bucketMatch, cb) {
    let azureKey = key;
    s3.getObject({ Bucket: azureContainerName, Key: azureKey }, (err, s3Res) => {
        assert.equal(err, null, `Err getting object from S3: ${err}`);
        assert.strictEqual(s3Res.ETag, `"${s3MD5}"`);

        if (!bucketMatch) {
            azureKey = `${azureContainerName}/${key}`;
        }
        azureClient.getContainerClient(azureContainerName).getProperties(azureKey).then(
            azureRes => {
                assert.strictEqual(expectedContentLength, azureRes.contentLength);
                cb();
            },
            err => {
                assert.equal(err, null, `Err getting object from Azure: ${err}`);
                cb();
            });
    });
}

function mpuSetup(key, location, cb) {
    const partArray = [];
    async.waterfall([
        next => {
            const params = {
                Bucket: azureContainerName,
                Key: key,
                Metadata: { 'scal-location-constraint': location },
            };
            s3.createMultipartUpload(params, (err, res) => {
                if (err) {
                    return next(err);
                }
                const uploadId = res.UploadId;
                assert(uploadId);
                assert.strictEqual(res.Bucket, azureContainerName);
                assert.strictEqual(res.Key, key);
                return next(null, uploadId);
            });
        },
        (uploadId, next) => {
            const partParams = {
                Bucket: azureContainerName,
                Key: key,
                PartNumber: 1,
                UploadId: uploadId,
                Body: smallBody,
            };
            s3.uploadPart(partParams, (err, res) => {
                if (err) {
                    return next(err);
                }
                partArray.push({ ETag: res.ETag, PartNumber: 1 });
                return next(null, uploadId);
            });
        },
        (uploadId, next) => {
            const partParams = {
                Bucket: azureContainerName,
                Key: key,
                PartNumber: 2,
                UploadId: uploadId,
                Body: bigBody,
            };
            s3.uploadPart(partParams, (err, res) => {
                if (err) {
                    return next(err);
                }
                partArray.push({ ETag: res.ETag, PartNumber: 2 });
                return next(null, uploadId);
            });
        },
    ], (err, uploadId) => {
        process.stdout.write('Created MPU and put two parts\n');
        assert.equal(err, null, `Err setting up MPU: ${err}`);
        cb(uploadId, partArray);
    });
}

describeSkipIfNotMultipleOrCeph('Complete MPU API for Azure data backend',
function testSuite() {
    this.timeout(150000);
    withV4(sigCfg => {
        beforeEach(function beFn() {
            this.currentTest.key = `somekey-${genUniqID()}`;
            bucketUtil = new BucketUtility('default', sigCfg);
            s3 = bucketUtil.s3;
            this.currentTest.awsClient = awsS3;
            return s3.createBucket({ Bucket: azureContainerName }).promise()
            .catch(err => {
                process.stdout.write(`Error creating bucket: ${err}\n`);
                throw err;
            });
        });

        afterEach(() => {
            process.stdout.write('Emptying bucket\n');
            return bucketUtil.empty(azureContainerName)
            .then(() => {
                process.stdout.write('Deleting bucket\n');
                return bucketUtil.deleteOne(azureContainerName);
            })
            .catch(err => {
                process.stdout.write(`Error in afterEach: ${err}\n`);
                throw err;
            });
        });

        it('should complete an MPU on Azure', function itFn(done) {
            mpuSetup(this.test.key, azureLocation, (uploadId, partArray) => {
                const params = {
                    Bucket: azureContainerName,
                    Key: this.test.key,
                    UploadId: uploadId,
                    MultipartUpload: { Parts: partArray },
                };
                s3.completeMultipartUpload(params, err => {
                    assert.equal(err, null, `Err completing MPU: ${err}`);
                    setTimeout(() => getCheck(this.test.key, true, done),
                        azureTimeout);
                });
            });
        });

        it('should complete an MPU on Azure with bucketMatch=false',
        function itFn(done) {
            mpuSetup(this.test.key, azureLocationMismatch,
            (uploadId, partArray) => {
                const params = {
                    Bucket: azureContainerName,
                    Key: this.test.key,
                    UploadId: uploadId,
                    MultipartUpload: { Parts: partArray },
                };
                s3.completeMultipartUpload(params, err => {
                    assert.equal(err, null, `Err completing MPU: ${err}`);
                    setTimeout(() => getCheck(this.test.key, false, done),
                        azureTimeout);
                });
            });
        });

        it('should complete an MPU on Azure with same key as object put ' +
        'to file', function itFn(done) {
            const body = Buffer.from('I am a body', 'utf8');
            s3.putObject({
                Bucket: azureContainerName,
                Key: this.test.key,
                Body: body,
                Metadata: { 'scal-location-constraint': fileLocation } },
            err => {
                assert.equal(err, null, `Err putting object to file: ${err}`);
                mpuSetup(this.test.key, azureLocation,
                (uploadId, partArray) => {
                    const params = {
                        Bucket: azureContainerName,
                        Key: this.test.key,
                        UploadId: uploadId,
                        MultipartUpload: { Parts: partArray },
                    };
                    s3.completeMultipartUpload(params, err => {
                        assert.equal(err, null, `Err completing MPU: ${err}`);
                        setTimeout(() => getCheck(this.test.key, true, done),
                            azureTimeout);
                    });
                });
            });
        });

        it('should complete an MPU on Azure with same key as object put ' +
        'to Azure', function itFn(done) {
            const body = Buffer.from('I am a body', 'utf8');
            s3.putObject({
                Bucket: azureContainerName,
                Key: this.test.key,
                Body: body,
                Metadata: { 'scal-location-constraint': azureLocation } },
            err => {
                assert.equal(err, null, `Err putting object to Azure: ${err}`);
                mpuSetup(this.test.key, azureLocation,
                (uploadId, partArray) => {
                    const params = {
                        Bucket: azureContainerName,
                        Key: this.test.key,
                        UploadId: uploadId,
                        MultipartUpload: { Parts: partArray },
                    };
                    s3.completeMultipartUpload(params, err => {
                        assert.equal(err, null, `Err completing MPU: ${err}`);
                        setTimeout(() => getCheck(this.test.key, true, done),
                            azureTimeout);
                    });
                });
            });
        });

        it('should complete an MPU on Azure with same key as object put ' +
        'to AWS', function itFn(done) {
            const body = Buffer.from('I am a body', 'utf8');
            s3.putObject({
                Bucket: azureContainerName,
                Key: this.test.key,
                Body: body,
                Metadata: { 'scal-location-constraint': awsLocation } },
            err => {
                assert.equal(err, null, `Err putting object to AWS: ${err}`);
                mpuSetup(this.test.key, azureLocation,
                (uploadId, partArray) => {
                    const params = {
                        Bucket: azureContainerName,
                        Key: this.test.key,
                        UploadId: uploadId,
                        MultipartUpload: { Parts: partArray },
                    };
                    s3.completeMultipartUpload(params, err => {
                        assert.equal(err, null, `Err completing MPU: ${err}`);
                        // make sure object is gone from AWS
                        setTimeout(() => {
                            this.test.awsClient.getObject({ Bucket: awsBucket,
                            Key: this.test.key }, err => {
                                assert.strictEqual(err.code, 'NoSuchKey');
                                getCheck(this.test.key, true, done);
                            });
                        }, azureTimeout);
                    });
                });
            });
        });
    });
});
