const assert = require('assert');
const async = require('async');
const arsenal = require('arsenal');
const { GCP } = arsenal.storage.data.external;
const { makeGcpRequest } = require('../../../utils/makeRequest');
const { gcpRequestRetry, genUniqID } = require('../../../utils/gcpUtils');
const { getRealAwsConfig } =
    require('../../../../aws-node-sdk/test/support/awsConfig');
const { listingHardLimit } = require('../../../../../../constants');

const credentialOne = 'gcpbackend';
const bucketName = `somebucket-${genUniqID()}`;
const smallSize = 20;
const bigSize = listingHardLimit + 1;
const config = getRealAwsConfig(credentialOne);
const gcpClient = new GCP(config);

function populateBucket(createdObjects, callback) {
    process.stdout.write(
        `Putting ${createdObjects.length} objects into bucket\n`);
    async.mapLimit(createdObjects, 10,
    (object, moveOn) => {
        makeGcpRequest({
            method: 'PUT',
            bucket: bucketName,
            objectKey: object,
            authCredentials: config.credentials,
        }, err => moveOn(err));
    }, err => {
        if (err) {
            process.stdout
                .write(`err putting objects ${err.code}`);
        }
        return callback(err);
    });
}

function removeObjects(createdObjects, callback) {
    process.stdout.write(
        `Deleting ${createdObjects.length} objects from bucket\n`);
    async.mapLimit(createdObjects, 10,
    (object, moveOn) => {
        makeGcpRequest({
            method: 'DELETE',
            bucket: bucketName,
            objectKey: object,
            authCredentials: config.credentials,
        }, err => moveOn(err));
    }, err => {
        if (err) {
            process.stdout
                .write(`err deleting objects ${err.code}`);
        }
        return callback(err);
    });
}

describe('GCP: GET Bucket', function testSuite() {
    this.timeout(180000);

    before(done => {
        gcpRequestRetry({
            method: 'PUT',
            bucket: bucketName,
            authCredentials: config.credentials,
        }, 0, err => {
            if (err) {
                process.stdout.write(`err in creating bucket ${err}\n`);
            }
            return done(err);
        });
    });

    after(done => {
        gcpRequestRetry({
            method: 'DELETE',
            bucket: bucketName,
            authCredentials: config.credentials,
        }, 0, err => {
            if (err) {
                process.stdout.write(`err in deleting bucket ${err}\n`);
            }
            return done(err);
        });
    });

    describe('without existing bucket', () => {
        it('should return 404 and NoSuchBucket', done => {
            const badBucketName = `nonexistingbucket-${genUniqID()}`;
            gcpClient.getBucket({
                Bucket: badBucketName,
            }, err => {
                assert(err);
                assert.strictEqual(err.statusCode, 404);
                assert.strictEqual(err.code, 'NoSuchBucket');
                return done();
            });
        });
    });

    describe('with existing bucket', () => {
        describe('with less than listingHardLimit number of objects', () => {
            const createdObjects = Array.from(
                Array(smallSize).keys()).map(i => `someObject-${i}`);

            before(done => populateBucket(createdObjects, done));

            after(done => removeObjects(createdObjects, done));

            it(`should list all ${smallSize} created objects`, done => {
                gcpClient.listObjects({
                    Bucket: bucketName,
                }, (err, res) => {
                    assert.equal(err, null, `Expected success, but got ${err}`);
                    assert.strictEqual(res.Contents.length, smallSize);
                    return done();
                });
            });

            describe('with MaxKeys at 10', () => {
                it('should list MaxKeys number of objects', done => {
                    gcpClient.listObjects({
                        Bucket: bucketName,
                        MaxKeys: 10,
                    }, (err, res) => {
                        assert.equal(err, null,
                            `Expected success, but got ${err}`);
                        assert.strictEqual(res.Contents.length, 10);
                        return done();
                    });
                });
            });
        });

        describe('with more than listingHardLimit number of objects', () => {
            const createdObjects = Array.from(
                Array(bigSize).keys()).map(i => `someObject-${i}`);

            before(done => populateBucket(createdObjects, done));

            after(done => removeObjects(createdObjects, done));

            it('should list at max 1000 of objects created', done => {
                gcpClient.listObjects({
                    Bucket: bucketName,
                }, (err, res) => {
                    assert.equal(err, null, `Expected success, but got ${err}`);
                    assert.strictEqual(res.Contents.length,
                        listingHardLimit);
                    return done();
                });
            });

            describe('with MaxKeys at 1001', () => {
                // TODO: S3C-5445
                // Note: this test is testing GCP behaviour, not the Cloudserver one.
                // It tests that GET https://<GCP_BUCKET_NAME>.storage.googleapis.com/?max-keys=1001
                // returns only the first 1000 objects.
                //
                // Expected behavior: the GCP XML API should not return a list longer
                // than 1000 objects, even if max-keys is greater than 1000:
                // https://cloud.google.com/storage/docs/xml-api/reference-headers#maxkeys
                //
                // Actual behavior: it returns a list longer than 1000 objects when
                // max-keys is greater than 1000
                it.skip('should list at max 1000, ignoring MaxKeys', done => {
                    gcpClient.listObjects({
                        Bucket: bucketName,
                        MaxKeys: 1001,
                    }, (err, res) => {
                        assert.equal(err, null,
                            `Expected success, but got ${err}`);
                        assert.strictEqual(res.Contents.length,
                            listingHardLimit);
                        return done();
                    });
                });
            });
        });
    });
});
