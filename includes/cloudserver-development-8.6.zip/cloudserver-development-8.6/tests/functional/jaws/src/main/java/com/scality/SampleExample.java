package com.scality;

//empty file to keep maven happy
public class SampleExample {
	
}
