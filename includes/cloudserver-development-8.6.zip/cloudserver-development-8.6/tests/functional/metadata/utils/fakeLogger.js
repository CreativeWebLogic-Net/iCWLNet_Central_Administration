const fakeLogger = {
    trace: () => {},
    error: () => {},
    info: () => {},
    debug: () => {},
    getSerializedUids: () => {},
};

module.exports = fakeLogger;
