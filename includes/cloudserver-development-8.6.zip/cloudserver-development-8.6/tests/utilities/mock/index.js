/* eslint-disable global-require */
const index = {
    Utapi: require('./Utapi'),
};

module.exports = index;
